﻿namespace SignRSA
{
    public class AppGlobal
    {
        public static int P{ get; set; }
        public static int Q{ get; set; }
        public static int N{ get; set; }
        public static int E{ get; set; }
        public static int D{ get; set; }
        public static int PhiN{ get; set; }

        public static string NoiDung { get; set; }

        public static string ChuKy { get; set; }


        public static string NoiDungnguyon { get; set; }

        public static string ChuKynguoi { get; set; }

    }
}
