﻿namespace SignRSA
{
    partial class KiemTraChuKy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtChuKy = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNoiDung = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnnhannoidung = new System.Windows.Forms.Button();
            this.btnkiemtra = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtnoidunggoc = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtchukygoc = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnGiaiMa = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtn = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txte = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblKetQua = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtChuKy
            // 
            this.txtChuKy.Location = new System.Drawing.Point(12, 283);
            this.txtChuKy.Multiline = true;
            this.txtChuKy.Name = "txtChuKy";
            this.txtChuKy.Size = new System.Drawing.Size(309, 131);
            this.txtChuKy.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(9, 267);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Chữ ký nhận được";
            // 
            // txtNoiDung
            // 
            this.txtNoiDung.Location = new System.Drawing.Point(12, 126);
            this.txtNoiDung.Multiline = true;
            this.txtNoiDung.Name = "txtNoiDung";
            this.txtNoiDung.Size = new System.Drawing.Size(309, 131);
            this.txtNoiDung.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(9, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nội dung nhận được";
            // 
            // btnnhannoidung
            // 
            this.btnnhannoidung.Location = new System.Drawing.Point(782, 119);
            this.btnnhannoidung.Name = "btnnhannoidung";
            this.btnnhannoidung.Size = new System.Drawing.Size(116, 23);
            this.btnnhannoidung.TabIndex = 10;
            this.btnnhannoidung.Text = "1. Nhận nội dung";
            this.btnnhannoidung.Click += new System.EventHandler(this.btnnhannoidung_Click);
            // 
            // btnkiemtra
            // 
            this.btnkiemtra.Location = new System.Drawing.Point(782, 172);
            this.btnkiemtra.Name = "btnkiemtra";
            this.btnkiemtra.Size = new System.Drawing.Size(116, 23);
            this.btnkiemtra.TabIndex = 10;
            this.btnkiemtra.Text = "3. Kiểm tra chữ ký";
            this.btnkiemtra.Click += new System.EventHandler(this.btnkiemtra_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(439, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nội dung";
            // 
            // txtnoidunggoc
            // 
            this.txtnoidunggoc.Location = new System.Drawing.Point(442, 126);
            this.txtnoidunggoc.Multiline = true;
            this.txtnoidunggoc.Name = "txtnoidunggoc";
            this.txtnoidunggoc.Size = new System.Drawing.Size(317, 131);
            this.txtnoidunggoc.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(443, 267);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Chữ ký";
            // 
            // txtchukygoc
            // 
            this.txtchukygoc.Location = new System.Drawing.Point(446, 283);
            this.txtchukygoc.Multiline = true;
            this.txtchukygoc.Name = "txtchukygoc";
            this.txtchukygoc.Size = new System.Drawing.Size(305, 131);
            this.txtchukygoc.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(346, 320);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 51);
            this.label5.TabIndex = 11;
            this.label5.Text = ">>";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(342, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 51);
            this.label6.TabIndex = 11;
            this.label6.Text = ">>";
            // 
            // btnGiaiMa
            // 
            this.btnGiaiMa.Location = new System.Drawing.Point(782, 145);
            this.btnGiaiMa.Name = "btnGiaiMa";
            this.btnGiaiMa.Size = new System.Drawing.Size(116, 23);
            this.btnGiaiMa.TabIndex = 10;
            this.btnGiaiMa.Text = "2. Giải mã";
            this.btnGiaiMa.Click += new System.EventHandler(this.btnGiaiMa_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtn);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txte);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 77);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cặp Số Công Khai";
            // 
            // txtn
            // 
            this.txtn.Location = new System.Drawing.Point(44, 29);
            this.txtn.Name = "txtn";
            this.txtn.Size = new System.Drawing.Size(70, 20);
            this.txtn.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(11, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(22, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "n = ";
            // 
            // txte
            // 
            this.txte.Location = new System.Drawing.Point(176, 29);
            this.txte.Name = "txte";
            this.txte.Size = new System.Drawing.Size(70, 20);
            this.txte.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(146, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "e = ";
            // 
            // lblKetQua
            // 
            this.lblKetQua.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKetQua.Location = new System.Drawing.Point(365, 24);
            this.lblKetQua.Name = "lblKetQua";
            this.lblKetQua.Size = new System.Drawing.Size(286, 53);
            this.lblKetQua.TabIndex = 4;
            // 
            // KiemTraChuKy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 494);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnGiaiMa);
            this.Controls.Add(this.btnkiemtra);
            this.Controls.Add(this.btnnhannoidung);
            this.Controls.Add(this.txtchukygoc);
            this.Controls.Add(this.txtChuKy);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtnoidunggoc);
            this.Controls.Add(this.lblKetQua);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNoiDung);
            this.Controls.Add(this.label1);
            this.Name = "KiemTraChuKy";
            this.Text = "Kiểm tra chữ ký";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtChuKy;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNoiDung;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnnhannoidung;
        private System.Windows.Forms.Button btnkiemtra;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtnoidunggoc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtchukygoc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnGiaiMa;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txte;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblKetQua;
    }
}