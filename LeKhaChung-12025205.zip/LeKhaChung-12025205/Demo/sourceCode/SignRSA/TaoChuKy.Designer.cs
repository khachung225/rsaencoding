﻿namespace SignRSA
{
    partial class TaoChuKy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtnoidung = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtchuky = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRoSo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMaHoa = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnmahoa = new System.Windows.Forms.Button();
            this.groupControl1 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.lblKetQua = new System.Windows.Forms.Label();
            this.btntaokhoa = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.txtd = new System.Windows.Forms.TextBox();
            this.btntaokhoamoi = new System.Windows.Forms.Button();
            this.txtn = new System.Windows.Forms.TextBox();
            this.labelControl6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txte = new System.Windows.Forms.TextBox();
            this.txtq = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.labelControl2 = new System.Windows.Forms.Label();
            this.txtn2 = new System.Windows.Forms.TextBox();
            this.labelControl4 = new System.Windows.Forms.Label();
            this.txtp = new System.Windows.Forms.TextBox();
            this.labelControl1 = new System.Windows.Forms.Label();
            this.btnkhoatudongmoi = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(10, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nội dung";
            // 
            // txtnoidung
            // 
            this.txtnoidung.Location = new System.Drawing.Point(13, 146);
            this.txtnoidung.Multiline = true;
            this.txtnoidung.Name = "txtnoidung";
            this.txtnoidung.Size = new System.Drawing.Size(325, 131);
            this.txtnoidung.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(10, 287);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã hóa chữ ký";
            // 
            // txtchuky
            // 
            this.txtchuky.Location = new System.Drawing.Point(13, 303);
            this.txtchuky.Multiline = true;
            this.txtchuky.Name = "txtchuky";
            this.txtchuky.Size = new System.Drawing.Size(325, 131);
            this.txtchuky.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(453, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Mã hóa nội dung";
            // 
            // txtRoSo
            // 
            this.txtRoSo.Location = new System.Drawing.Point(456, 146);
            this.txtRoSo.Multiline = true;
            this.txtRoSo.Name = "txtRoSo";
            this.txtRoSo.Size = new System.Drawing.Size(325, 131);
            this.txtRoSo.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(453, 287);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Chữ ký trên nội dung";
            // 
            // txtMaHoa
            // 
            this.txtMaHoa.Location = new System.Drawing.Point(456, 303);
            this.txtMaHoa.Multiline = true;
            this.txtMaHoa.Name = "txtMaHoa";
            this.txtMaHoa.Size = new System.Drawing.Size(325, 131);
            this.txtMaHoa.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(341, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 51);
            this.label5.TabIndex = 0;
            this.label5.Text = ">>";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(341, 551);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 51);
            this.label6.TabIndex = 0;
            this.label6.Text = "<<";
            // 
            // btnmahoa
            // 
            this.btnmahoa.Location = new System.Drawing.Point(794, 144);
            this.btnmahoa.Name = "btnmahoa";
            this.btnmahoa.Size = new System.Drawing.Size(97, 23);
            this.btnmahoa.TabIndex = 3;
            this.btnmahoa.Text = "2. Tạo Chữ ký";
            this.btnmahoa.UseVisualStyleBackColor = true;
            this.btnmahoa.Click += new System.EventHandler(this.btnmahoa_Click);
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.radioButton2);
            this.groupControl1.Controls.Add(this.lblKetQua);
            this.groupControl1.Controls.Add(this.btntaokhoa);
            this.groupControl1.Controls.Add(this.radioButton1);
            this.groupControl1.Controls.Add(this.txtd);
            this.groupControl1.Controls.Add(this.btntaokhoamoi);
            this.groupControl1.Controls.Add(this.txtn);
            this.groupControl1.Controls.Add(this.labelControl6);
            this.groupControl1.Controls.Add(this.label9);
            this.groupControl1.Controls.Add(this.txte);
            this.groupControl1.Controls.Add(this.txtq);
            this.groupControl1.Controls.Add(this.label10);
            this.groupControl1.Controls.Add(this.labelControl2);
            this.groupControl1.Controls.Add(this.txtn2);
            this.groupControl1.Controls.Add(this.labelControl4);
            this.groupControl1.Controls.Add(this.txtp);
            this.groupControl1.Controls.Add(this.labelControl1);
            this.groupControl1.Controls.Add(this.btnkhoatudongmoi);
            this.groupControl1.Location = new System.Drawing.Point(9, 14);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(893, 99);
            this.groupControl1.TabIndex = 13;
            this.groupControl1.TabStop = false;
            this.groupControl1.Text = "Tạo Cặp số";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(148, 25);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(73, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "Tự động";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // lblKetQua
            // 
            this.lblKetQua.AutoSize = true;
            this.lblKetQua.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKetQua.Location = new System.Drawing.Point(351, 14);
            this.lblKetQua.Name = "lblKetQua";
            this.lblKetQua.Size = new System.Drawing.Size(0, 29);
            this.lblKetQua.TabIndex = 11;
            // 
            // btntaokhoa
            // 
            this.btntaokhoa.Location = new System.Drawing.Point(785, 11);
            this.btntaokhoa.Name = "btntaokhoa";
            this.btntaokhoa.Size = new System.Drawing.Size(96, 23);
            this.btntaokhoa.TabIndex = 8;
            this.btntaokhoa.Text = "1. Tạo Số";
            this.btntaokhoa.Click += new System.EventHandler(this.btntaokhoa_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(24, 26);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(78, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Tùy chọn";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // txtd
            // 
            this.txtd.Location = new System.Drawing.Point(564, 58);
            this.txtd.Name = "txtd";
            this.txtd.Size = new System.Drawing.Size(70, 20);
            this.txtd.TabIndex = 7;
            // 
            // btntaokhoamoi
            // 
            this.btntaokhoamoi.Location = new System.Drawing.Point(785, 69);
            this.btntaokhoamoi.Name = "btntaokhoamoi";
            this.btntaokhoamoi.Size = new System.Drawing.Size(96, 23);
            this.btntaokhoamoi.TabIndex = 9;
            this.btntaokhoamoi.Text = "Nhập mới";
            this.btntaokhoamoi.Click += new System.EventHandler(this.btntaokhoamoi_Click_1);
            // 
            // txtn
            // 
            this.txtn.Location = new System.Drawing.Point(315, 58);
            this.txtn.Name = "txtn";
            this.txtn.Size = new System.Drawing.Size(70, 20);
            this.txtn.TabIndex = 4;
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(534, 63);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(22, 13);
            this.labelControl6.TabIndex = 0;
            this.labelControl6.Text = "d = ";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(282, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(22, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "n = ";
            // 
            // txte
            // 
            this.txte.Location = new System.Drawing.Point(447, 58);
            this.txte.Name = "txte";
            this.txte.Size = new System.Drawing.Size(70, 20);
            this.txte.TabIndex = 5;
            // 
            // txtq
            // 
            this.txtq.Location = new System.Drawing.Point(175, 58);
            this.txtq.Name = "txtq";
            this.txtq.Size = new System.Drawing.Size(70, 20);
            this.txtq.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(417, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "e = ";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(145, 63);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(22, 13);
            this.labelControl2.TabIndex = 0;
            this.labelControl2.Text = "q = ";
            // 
            // txtn2
            // 
            this.txtn2.Location = new System.Drawing.Point(704, 58);
            this.txtn2.Name = "txtn2";
            this.txtn2.Size = new System.Drawing.Size(70, 20);
            this.txtn2.TabIndex = 6;
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(652, 63);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(41, 13);
            this.labelControl4.TabIndex = 0;
            this.labelControl4.Text = "Ф(n) = ";
            // 
            // txtp
            // 
            this.txtp.Location = new System.Drawing.Point(49, 58);
            this.txtp.Name = "txtp";
            this.txtp.Size = new System.Drawing.Size(70, 20);
            this.txtp.TabIndex = 2;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(21, 63);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(22, 13);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "p = ";
            // 
            // btnkhoatudongmoi
            // 
            this.btnkhoatudongmoi.Location = new System.Drawing.Point(785, 41);
            this.btnkhoatudongmoi.Name = "btnkhoatudongmoi";
            this.btnkhoatudongmoi.Size = new System.Drawing.Size(96, 23);
            this.btnkhoatudongmoi.TabIndex = 10;
            this.btnkhoatudongmoi.Text = "1. Tự Tạo Số";
            this.btnkhoatudongmoi.Click += new System.EventHandler(this.tnkhoatudongmoi_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(794, 173);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "3. Kiểm tra";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TaoChuKy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 462);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnmahoa);
            this.Controls.Add(this.txtchuky);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtMaHoa);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtRoSo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtnoidung);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Name = "TaoChuKy";
            this.Text = "Tạo Chữ Ký";
            this.Load += new System.EventHandler(this.TaoChuKy_Load);
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtnoidung;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtchuky;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRoSo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMaHoa;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnmahoa;
        private System.Windows.Forms.GroupBox groupControl1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label lblKetQua;
        private System.Windows.Forms.Button btntaokhoa;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.TextBox txtd;
        private System.Windows.Forms.Button btntaokhoamoi;
        private System.Windows.Forms.TextBox txtn;
        private System.Windows.Forms.Label labelControl6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txte;
        private System.Windows.Forms.TextBox txtq;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelControl2;
        private System.Windows.Forms.TextBox txtn2;
        private System.Windows.Forms.Label labelControl4;
        private System.Windows.Forms.TextBox txtp;
        private System.Windows.Forms.Label labelControl1;
        private System.Windows.Forms.Button btnkhoatudongmoi;
        private System.Windows.Forms.Button button1;
    }
}

