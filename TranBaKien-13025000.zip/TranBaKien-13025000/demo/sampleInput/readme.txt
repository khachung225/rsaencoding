﻿Được dùng để chứa file input mẫu của ứng dụng nếu có
(Xoá file readme này đi trước khi nộp)