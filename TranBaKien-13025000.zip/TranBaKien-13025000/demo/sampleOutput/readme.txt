﻿Được dùng để chứa file output mẫu của ứng dụng
(Xoá file readme này đi trước khi nộp)