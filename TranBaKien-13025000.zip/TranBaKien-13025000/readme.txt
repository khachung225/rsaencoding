﻿Tên thư mục đặt đúng cấu trúc của demo này : HoVaTen-MSHV
Tên file doc chính đặt theo tên đề tài giống như VD để tiện tổng hợp
Ứng dụng ko có demo thì bỏ thư mục demo đi (Lưu ý không có ứng dụng demo thì điểm ko cao)
Tài liệu có thể có nhiều công thức, hình vẽ phức tạp nên mọi người thay vì dùng file word có thể xuất ra file PDF(embed font) để có thể xem tốt trên mọi máy.
* với File PDF tên file để tiếng việt không dấu mới mở được
Thầy Tiến rất tỉ mỉ và chú ý đến từ ngữ câu chữ nên mọi người nên chú ý và so lại với tài liệu của thầy để tránh sai sót không đáng có.
Cả lớp nộp bản mềm trước này 18/5/2014
Mọi người nén thư mục của mình thành một file .zip rồi up lên thư mục google drive đã đươc share. VD: TranBaKien-13025000.zip
(Xoá file readme này đi trước khi nộp)